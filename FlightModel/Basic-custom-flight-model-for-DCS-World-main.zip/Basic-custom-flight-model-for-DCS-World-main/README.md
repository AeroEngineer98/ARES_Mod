Thank you for checking out this flight model project!
Credit goes to CptSmiley for the F-16 flight model which I modified to make this.
You can find that version here: https://github.com/RagnarDa/F-16Demo

Microsoft Visual Studio (2019) is reccomended.

IMPORTANT:
Make sure to have Custom_FM.sln in a folder ABOVE the folder containing Custom_FM.vcxproj.

Feel free to do whatever you want with the source code, but please give credit where it is due.
